#include <iostream>
#include <list>
#include <vector>
#include "Profiler.h"

using namespace std;

enum SORTED_ORDER { RANDOM = 0, ASC, DESC };

const int RANGE_MIN = 1;
const int RANGE_MAX = 20;

template <class T>
struct Element {
    T key;
    int list_index;

    bool operator <(const Element& element) const
    {
        return this->key < element.key;
    }
};

template <class T>
class Heap
{
private:
    vector<T> data;
public:
    enum class HeapType {
        MIN_HEAP,
        MAX_HEAP
    };
    Heap(HeapType Type);
};

vector<list<int>> GenerateKSortedLists(int n, int k)
{
    vector<list<int>> result;
    vector<int> data(n / k + 1);

    int remainder = n % k, size;
    for (int i = 0; i < k; i++) {
        if (remainder > 0)
        {
            remainder--;
            size = n / k + 1;
        }
        else
        {
            size = n / k;
        }
        FillRandomArray(data.data(), size, RANGE_MIN, RANGE_MAX, false, SORTED_ORDER::ASC);
        result.push_back(list<int>(data.begin(), next(data.begin(), size)));
    }
    return result;
}

void Merge(list<int>& List1, list<int>& List2)
{
    if (List2.size() == 0)
        return;
    if (List1.size() == 0)
    {
        List1 = List2;
        return;
    }

    list<int>::iterator it1 = List1.begin();

    while (it1 != List1.end() && !List2.empty())
    {
        if (*it1 <= List2.front())
        {
            it1++;
        }
        else
        {
            List1.splice(it1, List2, List2.begin());
        }
    }

    List1.splice(it1, List2);
}

void PrintLists(vector<list<int>> Lists)
{
    int i = 0;
    for (list<int>& l : Lists)
    {
        cout << "list #" << i++ << ": ";
        for (int num : l)
        {
            cout << num << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}

int main()
{
    vector<list<int>> lists = GenerateKSortedLists(10, 2);
    PrintLists(lists);
    Merge(lists.at(0), lists.at(1));
    PrintLists(lists);
    return 0;
}